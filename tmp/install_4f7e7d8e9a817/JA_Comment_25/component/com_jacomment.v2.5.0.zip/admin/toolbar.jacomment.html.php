<?php
/**
 * ------------------------------------------------------------------------
 * JA Comment Component for Joomla 2.5
 * ------------------------------------------------------------------------
 * Copyright (C) 2004-2011 J.O.O.M Solutions Co., Ltd. All Rights Reserved.
 * @license - GNU/GPL, http://www.gnu.org/licenses/gpl.html
 * Author: J.O.O.M Solutions Co., Ltd
 * Websites: http://www.joomlart.com - http://www.joomlancers.com
 * ------------------------------------------------------------------------
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

/**
 * JA Comment toolbar
 *
 * @package		Joomla.Administrator
 * @subpackage	JAComment
 */
class TOOLBAR_JACOMMENT
{
	/**
	 * Default toolbar
	 * 
	 * @param string $text Toolbar title
	 * 
	 * @return void
	 */
	function _DEFAULT($text = 'JA_COMMENT')
	{
		JToolBarHelper::title(JText::_($text), 'generic.png');
		JToolBarHelper::help('screen.jacomment');
	}
	
	/**
	 * JACComment function
	 * 
	 * @param string $text Toolbar title
	 * 
	 * @return void
	 */
	function JACCOMMENT($text = '')
	{
		JToolBarHelper::title(JText::_($text));
		$task = JRequest::getCmd('task', '');
		switch ($task) {
			case 'add':
			case 'save':
			case 'apply':
			case 'edit':
				JToolBarHelper::apply();
				JToolBarHelper::save();
				JToolBarHelper::cancel();
				break;
			default:
				JToolBarHelper::publish("approve", JText::_("APPROVE"));
				JToolBarHelper::unpublish("unapprove", JText::_("UNAPPROVE"));
				JToolBarHelper::custom('spam', 'trash.png', 'trash.png', JText::_('MARK_SPAM'), false, false);
				JToolBarHelper::custom('delete', 'delete.png', 'delete.png', JText::_('DELETE'), false, false);
				break;
		}
	}
	
	/**
	 * JACReports function
	 * 
	 * @param string $text Toolbar title
	 * 
	 * @return void
	 */
	function JACReports($text = '')
	{
		JToolBarHelper::title(JText::_($text));
		$task = JRequest::getCmd('task', '');
		switch ($task) {
			case '':
			default:
				JToolBarHelper::publish();
				JToolBarHelper::unpublish();
				JToolBarHelper::deleteList(JText::_('WARNING_BEFOR_DISMISS'), 'dismiss_all', JText::_('DISMISS'));
				break;
		}
	}
	
	/**
	 * JACEmails function
	 * 
	 * @return void
	 */
	function JACEmails()
	{
		$task = JRequest::getCmd('task', '');
		JToolBarHelper::title(JText::_('EMAIL_TEMPLATE_MANAGER'));
		switch ($task) {
			case 'add':
			case 'edit':
				JToolBarHelper::apply();
				JToolBarHelper::save();
				JToolBarHelper::cancel();
				break;
			case 'show_duplicate':
			case 'show_import':
			case 'show_export':
				return;
			default:
				JToolBarHelper::custom('show_duplicate', 'copy', '', JText::_('COPY_TO'));
				JToolBarHelper::custom('show_import', 'back', '', JText::_('IMPORT'), false);
				JToolBarHelper::custom('export', 'forward', '', JText::_('EXPORT'));
				JToolBarHelper::publishList();
				JToolBarHelper::unpublishList();
				JToolBarHelper::deleteList(JText::_('ARE_YOU_SURE_TO_DELETE'));
				JToolBarHelper::editListX();
				JToolBarHelper::addNewX();
				break;
		}
	}
	
	/**
	 * JACConfigs function
	 * 
	 * @return void
	 */
	function JACConfigs()
	{
		$group = JRequest::getCmd('group', '');
		JToolBarHelper::title(JText::_('CONFIGURATION_MANAGER'));
		
		if ($group == 'layout') {
			JToolBarHelper::save("save", JText::_("SAVE"));
		} elseif ($group == 'moderator') {
			JToolBarHelper::addNewX('add', JText::_('ADD_USER'));
			JToolBarHelper::deleteListX();
		} else {
			JToolBarHelper::save("save", JText::_("SAVE"));
		}
	}
	
	/**
	 * JACDesign function
	 * 
	 * @param string $title Toolbar title
	 * 
	 * @return void
	 */
	function JACDesign($title = '')
	{
		$task = JRequest::getCmd('task', '');
		$controller = JRequest::getCmd('view', null);
		if (! $title) {
			switch ($controller) {
				case 'jacustomcss':
					$title = JText::_("CUSTOM_CSS");
					break;
				case 'jacustomtmpl':
					$title = JText::_("CUSTOM_TEMPLATE");
					break;
				case 'managelang':
					$title = JText::_("CUSTOM_LANGUAGE");
					break;
				default:
					$title = '';
					break;
			}
		}
		JToolBarHelper::title($title);
		if ($task == 'edit') {
			JToolBarHelper::save();
			JToolBarHelper::cancel();
		}
	
	}
	
	/**
	 * JACImexport function
	 * 
	 * @return void
	 */
	function JACImexport()
	{
		$task = JRequest::getCmd('task', '');
		if ($task == "showComment") {
			JToolBarHelper::publish("approve", JText::_("APPROVE"));
			JToolBarHelper::unpublish("unapprove", JText::_("UNAPPROVE"));
			JToolBarHelper::custom('spam', 'trash.png', 'trash.png', JText::_('MARK_SPAM'), false, false);
			JToolBarHelper::custom('delete', 'delete.png', 'delete.png', ('DELETE'), false, false);
		}
	}
}
?>