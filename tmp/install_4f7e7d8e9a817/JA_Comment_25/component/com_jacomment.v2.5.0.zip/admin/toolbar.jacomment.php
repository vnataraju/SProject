<?php
/**
 * ------------------------------------------------------------------------
 * JA Comment Component for Joomla 2.5
 * ------------------------------------------------------------------------
 * Copyright (C) 2004-2011 J.O.O.M Solutions Co., Ltd. All Rights Reserved.
 * @license - GNU/GPL, http://www.gnu.org/licenses/gpl.html
 * Author: J.O.O.M Solutions Co., Ltd
 * Websites: http://www.joomlart.com - http://www.joomlancers.com
 * ------------------------------------------------------------------------
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

// DEVNOTE: Pull in the class that will be used to actually display our toolbar.
require_once JApplicationHelper::getPath('toolbar_html');

$view = JRequest::getCmd('view', '');

switch ($view) {
	case 'comments':
		TOOLBAR_JACOMMENT::JACCOMMENT('JA_COMMENT');
		break;
	case 'emailtemplates':
		TOOLBAR_JACOMMENT::JACEmails();
		break;
	case 'configs':
		TOOLBAR_JACOMMENT::JACConfigs();
		break;
	case 'imexport':
		TOOLBAR_JACOMMENT::_DEFAULT('JA_IMPORT_EXPORT');
		break;
	case 'customtmpl':
	case 'customcss':
	case 'managelang':
		TOOLBAR_JACOMMENT::JACDesign();
		break;
	case 'moderate':
		TOOLBAR_JACOMMENT::JACModetare();
		break;
	default:
		TOOLBAR_JACOMMENT::_DEFAULT();
		break;
}
?>
