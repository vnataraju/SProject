<?php
/**
 * ------------------------------------------------------------------------
 * JA Comment Component for Joomla 2.5
 * ------------------------------------------------------------------------
 * Copyright (C) 2004-2011 J.O.O.M Solutions Co., Ltd. All Rights Reserved.
 * @license - GNU/GPL, http://www.gnu.org/licenses/gpl.html
 * Author: J.O.O.M Solutions Co., Ltd
 * Websites: http://www.joomlart.com - http://www.joomlancers.com
 * ------------------------------------------------------------------------
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controller');

/**
 * Component Controller
 *
 * @package		Joomla.Administrator
 * @subpackage	JAComment
 */
class JACommentController extends JController
{
	/**
	 * Method to display a view
	 * 
	 * @return void
	 */
	function display()
	{
		$view = JRequest::getCmd('view');
		if (! JRequest::getCmd('tmpl') && $view != 'emailtemplates') {
			echo '<div id="jac-msg-succesfull" style="display:none"></div>';
			?>
			<script type="text/javascript">
			var siteurl = '<?php
			echo JURI::base() . "index.php?tmpl=component&option=com_jacomment&view=" . $view;
			?>';
			</script>
			<?php
		}
		parent::display();
		
		return $this;
	}
}
?>