<?php
/**
 * ------------------------------------------------------------------------
 * JA Comment Component for Joomla 2.5
 * ------------------------------------------------------------------------
 * Copyright (C) 2004-2011 J.O.O.M Solutions Co., Ltd. All Rights Reserved.
 * @license - GNU/GPL, http://www.gnu.org/licenses/gpl.html
 * Author: J.O.O.M Solutions Co., Ltd
 * Websites: http://www.joomlart.com - http://www.joomlancers.com
 * ------------------------------------------------------------------------
 */
// no direct access
defined ( '_JEXEC' ) or die ( 'Restricted access' ); 

jimport('joomla.filesystem.folder');
jimport('joomla.filesystem.file');
/**
 * This controller is used for JACustomcss feature of the component
 *
 * @package		Joomla.Administrator
 * @subpackage	JAComment
 */
class JACommentControllerCustomcss extends JACommentController
{
	/**
	 * Constructor
	 * 
	 * @param array $location Array of configuration settings
	 * 
	 * @return void
	 */
	function __construct($location = array())
	{
		parent::__construct($location);
		// Register Extra tasks
		$this->registerTask('apply', 'save');
	}
	
	/**
	 * Display current customcss of the component to administrator
	 * 
	 * @return void
	 * 
	 */
	function display()
	{
		switch ($this->getTask()) {
			case 'edit':
			default:
				JRequest::setVar('hidemainmenu', 1);
				JRequest::setVar('edit', true);
				JRequest::setVar('layout', 'form');
				break;
		}
		
		parent::display();
		
		return $this;
	}
	
	/**
	 * Cancel current operation
	 * 
	 * @return boolean True if have no error and vice versa
	 * 
	 */
	function cancel()
	{
		$option = JRequest::getCmd('option');
		$this->setRedirect("index.php?option=$option&view=customcss");
		return true;
	}
	
	/**
	 * Save record
	 * 
	 * @return boolean True if have no error and vice versa
	 */
	function save()
	{
		$option = JRequest::getCmd('option');
		// Check for request forgeries
		JRequest::checkToken() or jexit('Invalid Token');
		
		$content = JRequest::getString('content', '', 'post', JREQUEST_ALLOWRAW);
		
		$file = JRequest::getString('file', '');
		$path = '';
		$template = JACommentHelpers::checkFileTemplate($file);
		if ($template) {
			$path = $template;
		} else {
			$path = JPATH_COMPONENT_SITE . DS . 'asset' . DS . 'css' . DS . $file;
		}
		$msg = '';
		if (JFile::exists($path)) {
			$res = JFile::write($path, $content);
			if ($res) {
				$msg = JText::_('SAVE_DATA_SUCCESSFULLY') . ': ' . $file;
			} else {
				JError::raiseWarning(1001, JText::_("ERROR_DATA_NOT_SAVED") . " " . $file);
			}
		} else {
			JError::raiseWarning(1001, JText::_("FILE_NOT_FOUND_TO_EDIT"));
		}
		
		switch ($this->_task) {
			case 'apply':
				$this->setRedirect("index.php?option=$option&view=customcss&task=edit&file=$file", $msg);
				break;
			
			case 'save':
			default:
				$this->setRedirect("index.php?option=$option&view=customcss", $msg);
				break;
		}
		return true;
	}
}
?>