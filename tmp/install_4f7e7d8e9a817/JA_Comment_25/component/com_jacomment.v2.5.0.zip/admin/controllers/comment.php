<?php
/**
 * ------------------------------------------------------------------------
 * JA Comment Component for Joomla 2.5
 * ------------------------------------------------------------------------
 * Copyright (C) 2004-2011 J.O.O.M Solutions Co., Ltd. All Rights Reserved.
 * @license - GNU/GPL, http://www.gnu.org/licenses/gpl.html
 * Author: J.O.O.M Solutions Co., Ltd
 * Websites: http://www.joomlart.com - http://www.joomlancers.com
 * ------------------------------------------------------------------------
 */
defined('_JEXEC') or die('Restricted access');

/**
 * jacommentControllercomment controller
 *
 * @package		Joomla.Administrator
 * @subpackage	JAComment
 */
class jacommentControllercomment extends JACommentController
{
	/**
	 * Constructor
	 * 
	 * @param array $default Array of configuration settings
	 * 
	 * @return void
	 */
	function __construct($default = array())
	{
		parent::__construct($default);
		// Register Extra tasks
		JRequest::setVar('view', 'comment');
		$this->registerTask('add', 'edit');
		$this->registerTask('apply', 'save');
	}
	
	/**
	 * Display function
	 * 
	 * @return void
	 */
	function display()
	{
		$user = JFactory::getUser();
		$task = $this->getTask();
		switch ($task) {
			case 'verify':
				$post = JRequest::get('post', JREQUEST_ALLOWHTML);
				if (count($post) > 0 && $post['email'] != '' && $post['payment_id'] != '') {
					$objVerify = new JACommentLicense($post['email'], $post['payment_id']);
					$objVerify->verify_license($post['email'], $post['payment_id']);
				}
				JRequest::setVar('layout', 'verify');
				break;
			default:
				// other tasks
				break;
		}
		if ($user->id == 0) {
			JError::raiseWarning(1001, JText::_("YOU_MUST_BE_SIGNED_IN"));
			$this->setRedirect(JRoute::_("index.php?option=com_user&view=login"));
			return;
		}
		parent::display();
		
		return $this;
	}
}
?>