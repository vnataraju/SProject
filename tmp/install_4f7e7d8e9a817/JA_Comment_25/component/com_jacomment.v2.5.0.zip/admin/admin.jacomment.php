<?php
/**
 * ------------------------------------------------------------------------
 * JA Comment Component for Joomla 2.5
 * ------------------------------------------------------------------------
 * Copyright (C) 2004-2011 J.O.O.M Solutions Co., Ltd. All Rights Reserved.
 * @license - GNU/GPL, http://www.gnu.org/licenses/gpl.html
 * Author: J.O.O.M Solutions Co., Ltd
 * Websites: http://www.joomlart.com - http://www.joomlancers.com
 * ------------------------------------------------------------------------
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

// Require Helper
require_once JPATH_SITE . DS . 'components' . DS . 'com_jacomment' . DS . 'helpers' . DS . 'jahelper.php';
$GLOBALS['jacconfig'] = array();
JACommentHelpers::get_config_system();

require_once JPATH_COMPONENT_ADMINISTRATOR . DS . 'asset' . DS . 'jaconstants.php';
// Require the base controller
require_once JPATH_COMPONENT . DS . 'controller.php';

//Require the submenu for component
require_once JPATH_COMPONENT . DS . 'views' . DS . 'jaview' . DS . 'view.html.php';

$javersion = new JVersion();

JHtml::_('behavior.framework', true);

if(!defined('JACOMMENT_GLOBAL_FRONT_END_CSS')){
		global $jacconfig,$mainframe;
		$mainframe = JFactory::getApplication();
		$theme 	= $jacconfig['layout']->get('theme', 'default' );
		
		if(file_exists(JPATH_ROOT.DS.'components/com_jacomment/themes/'.$theme.'/css/style.css')){		
			JHTML::stylesheet('style.css', JURI::root().'components/com_jacomment/themes/'.$theme.'/css/');
		}
		if(file_exists(JPATH_ROOT.DS.'templates'.DS.$mainframe->getTemplate().DS.'html'.DS."com_jacomment".DS."themes".DS. $theme .DS."css".DS."style.css")){		
			JHTML::stylesheet('style.css', JURI::root().'templates/'.$mainframe->getTemplate().'/html/com_jacomment/themes/'.$theme.'/css/');	 
		}
			
		if(file_exists(JPATH_ROOT.DS.'components/com_jacomment/themes/'.$theme.'/css/style.ie.css')){
		    JHTML::stylesheet('style_ie.css', JURI::root().'components/com_jacomment/themes/'.$theme.'/css/');
		}	
		if(file_exists(JPATH_ROOT.DS.'templates'.DS.$mainframe->getTemplate().DS.'html'.DS."com_jacomment".DS."themes".DS. $theme .DS."css".DS."style.ie.css")){		
			JHTML::stylesheet('style.ie.css', JURI::root().'templates/'.$mainframe->getTemplate().'/html/com_jacomment/themes/'.$theme.'/css/');	 
		}
		 define('JACOMMENT_GLOBAL_FRONT_END_CSS', true); 
}
if (! defined('JACOMMENT_GLOBAL_SKIN')) {
	JHTML::_('stylesheet', JURI::root() . 'administrator/components/com_jacomment/asset/css/' . 'ja.comment.css');
	JHTML::_('stylesheet', JURI::root() . 'components/com_jacomment/asset/css/ja.popup.css');
	
	JHTML::_('script', JURI::root() . 'components/com_jacomment/asset/js/jquery-1.4.2.js');
	JHTML::_('script', JURI::root() . 'administrator/components/com_jacomment/asset/js/ja.comment.js');
	JHTML::_('script', JURI::root() . 'administrator/components/com_jacomment/asset/js/jquery.savecomment.js');
	JHTML::_('script', JURI::root() . 'administrator/components/com_jacomment/asset/js/ja.popup.js');
	
	define('JACOMMENT_GLOBAL_SKIN', true);
}

if (! defined('JACOMMENT_PLUGIN_ATD')) {
	JHTML::_('stylesheet', JURI::root() . 'components/com_jacomment/asset/css/atd.css');
	JHTML::_('script', JURI::root() . 'components/com_jacomment/libs/js/atd/jquery.atd.js');
	JHTML::_('script', JURI::root() . 'components/com_jacomment/libs/js/atd/csshttprequest.js');
	JHTML::_('script', JURI::root() . 'components/com_jacomment/libs/js/atd/atd.js');
	
	define('JACOMMENT_PLUGIN_ATD', true);
}

jimport('joomla.application.component.model');
JModel::addIncludePath(JPATH_ROOT . DS . 'components' . DS . 'com_jacomment' . DS . 'models');

if (! JRequest::getCmd('view')) {
	JRequest::setVar('view', 'comments');
}

if ($controller = JRequest::getCmd('view')) {
	$path = JPATH_COMPONENT . DS . 'controllers' . DS . $controller . '.php';
	if (file_exists($path)) {
		include_once $path;
	} else {
		$controller = '';
	}
}

// Create the controller
$classname = 'JACommentController' . ucfirst($controller);
$controller = new $classname();

$task = JRequest::getCmd('task', null, 'default');

// Perform the Request task
$controller->execute($task);

// Redirect if set by the controller
$controller->redirect();
?>