<?php
/**
 * ------------------------------------------------------------------------
 * JA Comment Component for Joomla 2.5
 * ------------------------------------------------------------------------
 * Copyright (C) 2004-2011 J.O.O.M Solutions Co., Ltd. All Rights Reserved.
 * @license - GNU/GPL, http://www.gnu.org/licenses/gpl.html
 * Author: J.O.O.M Solutions Co., Ltd
 * Websites: http://www.joomlart.com - http://www.joomlancers.com
 * ------------------------------------------------------------------------
 */
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');

/**
 * This view is used for JAImexport feature of the component
 * 
 * @package		Joomla.Administrator
 * @subpackage	JAComment
 */
class JACommentViewImexport extends JAView
{
	/**
	 * Display the view
	 * 
	 * @param string $tmpl The name of the template file
	 * 
	 * @return void
	 */
	function display($tmpl = null)
	{
		global $db;
		
		$group = JRequest::getCmd('group', 'import');
		$type = JRequest::getCmd('type');
		$task = JRequest::getCmd('task', null, 'default');
		
		if ($task == "showcomment") {
			$this->setLayout("showlist");
			
			$this->showComment();
			$source = JRequest::getString('source', '');
			$this->assignRef('source', $source);
		} else if ($task == "open_content") {
			$this->showcontent();
		} else {
			$this->setLayout($group);
			$model = &JModel::getInstance('Imexport', 'JACommentModel');
			$OtherCommentSystems = $model->JAOtherCommentSystem();
			
			$tables = $model->showTables();
			
			foreach ($tables as $table) {
				for ($i = 0, $n = count($OtherCommentSystems); $i < $n; $i++) {
					$table_chk = str_replace('#_', '', $OtherCommentSystems[$i]['table']);
					
					if (preg_match('/' . $table_chk . '$/i', $table)) {
						$OtherCommentSystems[$i]['status'] = true;
						$OtherCommentSystems[$i]['total'] = $model->totalRecord($table);
					}
				}
			}
			
			$this->assignRef('OtherCommentSystems', $OtherCommentSystems);
			
			$source = JRequest::getString('source', '');
			$this->assignRef('source', $source);
			$this->assignRef('group', $group);
		
		}
		
		parent::display($tmpl);
	}
	
	/**
	 * Show comment from file
	 * 
	 * @return unknown_type
	 */
	function showComment()
	{
		JRequest::setVar('layout', 'import');
		
		$model = & $this->getModel('imexport');
		
		$source = JRequest::getString('source');
		
		jimport('joomla.filesystem.file');
		
		if (isset($_FILES[$source]) && $_FILES[$source]['name'] != '' && strtolower(substr($_FILES[$source]['name'], - 3, 3)) == 'xml') {
			$file = JPATH_COMPONENT_ADMINISTRATOR . DS . 'temp' . DS . substr($_FILES[$source]['name'], 0, strlen($_FILES[$source]['name']) - 4) . time() . rand() . substr($_FILES[$source]['name'], - 4, 4);
			
			if (JFile::upload($_FILES[$source]['tmp_name'], $file)) {
				unset($_FILES[$source]);
				
				$xml = & JFactory::getXMLParser('simple');
				
				$xml->loadFile($file);
				$out = & $xml->document;
				
				//check is valid xml document
				if ($out == false) {
					JError::raiseNotice(1, JText::_('PLEASE_BROWSE_A_VALID_XML_FILE'));
					return JController::setRedirect("index.php?option=com_jacomment&view=imexport&group=import", '');
				} else {
					$allComments = $out->children();
					if ($allComments[0]->name() != "article") {
						JError::raiseNotice(1, JText::_('PLEASE_SELECT_XML_FILE_OF_DISQUS_COMMENTS'));
						return JController::setRedirect("index.php?option=com_jacomment&view=imexport&group=import");
					}
					
					//disqus
					$site_url = JRequest::getString("site_url", "joomlart");
					
					$items = array();
					$i = 0;
					$rows = array();
					foreach ($allComments as $blogpost) {
						foreach ($blogpost->children() as $comments) {
							$other[$comments->name()] = $comments->data();
							foreach ($comments->children() as $key => $value) {
								$comment[$key] = $value->children();
								foreach ($comment[$key] as $v) {
									if ($site_url == "" || strpos($other["url"], $site_url) !== false) {
										$rows[$key][$v->name()] = $v->data();
									}
								}
							}
						}
						if ($site_url == "" || strpos($other["url"], $site_url) !== false) {
							$items[$other["url"]] = $rows;
						}
						$rows = array();
					}
					if (! $items || count($items) < 1) {
						JError::raiseNotice(1, JText::_('NO_COMMENT_IN_XML_FILE_WAS_FOUND'));
						return JController::setRedirect("index.php?option=com_jacomment&view=imexport&group=import");
					}
					$this->assign("items", $items);
					$this->assign("allComponents", $this->getAllComponent());
				}
			} else {
				JError::raiseNotice(1, JText::_('CAN_NOT_IMPORT_THE_DATA'));
				return JController::setRedirect("index.php?option=com_jacomment&view=imexport&group=import");
			}
		} else {
			JError::raiseNotice(1, JText::_('CAN_NOT_IMPORT_THE_DATA_PLEASE_BROWSE_AN_XML_FILE'));
			return JController::setRedirect("index.php?option=com_jacomment&view=imexport&group=import");
		}
	}
	
	/**
	 * Check a component exists or not
	 * 
	 * @param string $componentOption Component name
	 * 
	 * @return integer Component is existed or not
	 */
	function checkExistComponent($componentOption)
	{
		$model = &JModel::getInstance('Imexport', 'JACommentModel');
		return $model->checkExistComponent($componentOption);
	}
	
	/**
	 * Get all component
	 * 
	 * @return array Array of components
	 */
	function getAllComponent()
	{
		$model = &JModel::getInstance('Imexport', 'JACommentModel');
		return $model->getAllComponent();
	}
	
	/**
	 * Get article from link
	 * 
	 * @param string $link Article link
	 * 
	 * @return object Item object
	 */
	function getComponentFromAriticle($link)
	{
		$model = &JModel::getInstance('Imexport', 'JACommentModel');
		return $model->getComponentFromAricleLink($link);
	}
	
	/**
	 * Get link of myblog component
	 * 
	 * @param integer $id Item id
	 * 
	 * @return string Link of item
	 */
	function getMyBlogLink($id)
	{
		$model = &JModel::getInstance('Imexport', 'JACommentModel');
		$permalink = $model->getMyBlogLink($id);
		return JRoute::_("index.php?option=com_myblog&show={$permalink}&Itemid={$id}");
	}
	
	/**
	 * Show menu in tab view
	 * 
	 * @return string Tab view in HTML code
	 */
	function getTabs()
	{
		$option = JRequest::getCmd('option');
		$group = JRequest::getString('group', '');
		$tabs = '<div class="submenu-box">
						<div class="submenu-pad">
							<ul id="submenu" class="configuration">
								<li><a href="index.php?option=' . $option . '&view=imexport&group=import"';
		if ($group == 'import' || $group == '') {
			$tabs .= ' class="active" ';
		}
		$tabs .= '>';
		$tabs .= JText::_('IMPORT_DATA') . '</a></li>';
		
		$tabs .= '<li><a href="index.php?option=' . $option . '&view=imexport&group=export"';
		if ($group == 'export') {
			$tabs .= ' class="active" ';
		}
		$tabs .= '>';
		$tabs .= JText::_('EXPORT_DATA') . '</a></li>';
		
		$tabs .= '				</ul>
							<div class="clr"></div>
						</div>
					</div>
					<div class="clr"></div>';
		return $tabs;
	}
	
	/**
	 * Show K2 content
	 * 
	 * @return void
	 */
	function showcontentk2()
	{
		$this->assign("component", "com_k2");
	}
	
	/**
	 * Show content from content or myblog component
	 * 
	 * @return void
	 */
	function showcontent()
	{
		$model = &JModel::getInstance('Imexport', 'JACommentModel');
		$component[] = "com_content";
		$isExitComBlog = $model->checkComBlog();
		if ($isExitComBlog) {
			$component[] = "com_myblog";
		}
		$this->assign("component", $component);
	}
	
	/**
	 * Get list of components
	 * 
	 * @return array List of components installed on system
	 */
	function getListComponent()
	{
		$list = array();
		$list[] = "com_content";
		$model = &JModel::getInstance('Imexport', 'JACommentModel');
		if ($model->checkExistComponent("com_myblog")) {
			$list[] = "com_myblog";
		}
		if ($model->checkExistComponent("com_k2")) {
			$list[] = "com_k2";
		}
		return $list;
	}
}
?>