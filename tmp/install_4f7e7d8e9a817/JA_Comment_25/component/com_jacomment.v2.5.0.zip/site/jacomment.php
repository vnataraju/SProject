<?php
/**
 * ------------------------------------------------------------------------
 * JA Comment Component for Joomla 2.5
 * ------------------------------------------------------------------------
 * Copyright (C) 2004-2011 J.O.O.M Solutions Co., Ltd. All Rights Reserved.
 * @license - GNU/GPL, http://www.gnu.org/licenses/gpl.html
 * Author: J.O.O.M Solutions Co., Ltd
 * Websites: http://www.joomlart.com - http://www.joomlancers.com
 * ------------------------------------------------------------------------
 */
/*
 * DEVNOTE: This is the 'main' file. 
 * It's the one that will be called when we go to the JAComment component. 
 */
// no direct access
defined('_JEXEC') or die('Restricted access');

//Require the submenu for component
jimport('joomla.application.component.model');
jimport('joomla.utilities.date');
jimport('joomla.application.component.controller');

JTable::addIncludePath(JPATH_SITE . DS . 'administrator' . DS . 'components' . DS . 'com_jacomment' . DS . 'tables');

//------------------------------check Component Offline-------------------------
/* Require Helper */
require_once JPATH_SITE . DS . 'components' . DS . 'com_jacomment' . DS . 'helpers' . DS . 'jahelper.php';
require_once JPATH_SITE . DS . 'components' . DS . 'com_jacomment' . DS . 'helpers' . DS . 'jacaptcha' . DS . 'jacapcha.php';

$GLOBALS['jacconfig'] = array();
JACommentHelpers::get_config_system();
global $jacconfig;

if (isset($jacconfig['general']) && $jacconfig['general']->get('is_comment_offline', 0)) {
	if (! JACommentHelpers::check_access()) {
		return;
	}
}
if (! isset($_SESSION['JAC_LAST_VISITED'])) {
	if (isset($_COOKIE['JAC_LAST_VISITED'])) {
		$_SESSION['JAC_LAST_VISITED'] = $_COOKIE['JAC_LAST_VISITED'];
	} else {
		$_SESSION['JAC_LAST_VISITED'] = strtotime(date("Y-m-d") . " -3 days");
	}
	setcookie('JAC_LAST_VISITED', time());
}

$app = JFactory::getApplication();
$checkTheme = $jacconfig['layout']->get('theme', 'default');
if (!JFolder::exists('templates/' . $app->getTemplate() . '/html/com_jacomment/themes/' . $checkTheme)) {
	$jacconfig['layout']->set('theme', 'default');
}

if (! JRequest::getCmd('view')) {
	JRequest::setVar('view', 'comments');
}
$controller = JRequest::getCmd('view');

require_once JPATH_SITE . DS . 'components' . DS . 'com_jacomment' . DS . 'controller.php';
$view = $controller;
if ($controller) {
	$path = JPATH_SITE . DS . 'components' . DS . 'com_jacomment' . DS . 'controllers' . DS . $controller . '.php';
	if (file_exists($path)) {
		include_once $path;
	} else {
		$controller = '';
	}
}

if (! defined('JACOMMENT_GLOBAL_JS')) {
	JHTML::script('components/com_jacomment/asset/js/jquery-1.4.2.js');
	JHTML::script('components/com_jacomment/asset/js/ja.comment.js');
	JHTML::script('components/com_jacomment/asset/js/ja.popup.js');
	define('JACOMMENT_GLOBAL_JS', true);
}

// Create the controller
$classname = 'JACommentController' . ucfirst($controller);
$controller = new $classname();

$controller->_basePath = JPATH_SITE . DS . 'components' . DS . 'com_jacomment';
$controller->_path['view'][0] = JPATH_SITE . DS . 'components' . DS . 'com_jacomment' . DS . 'views' . DS;

$task = JRequest::getCmd('task', null, 'default');

$controller->execute($task);

// Redirect if set by the controller
$controller->redirect();
?>