<?php
/**
 * ------------------------------------------------------------------------
 * JA System Nrain Plugin for Joomla 2.5
 * ------------------------------------------------------------------------
 * Copyright (C) 2004-2011 J.O.O.M Solutions Co., Ltd. All Rights Reserved.
 * @license - GNU/GPL, http://www.gnu.org/licenses/gpl.html
 * Author: J.O.O.M Solutions Co., Ltd
 * Websites: http://www.joomlart.com - http://www.joomlancers.com
 * ------------------------------------------------------------------------
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.plugin.plugin');
jimport('joomla.user.helper');
/**
 * Janrain Content Plugin
 *
 * @package		Joomla
 * @subpackage	Content
 * @since 		1.6
 */
class plgSystemjanrain extends JPlugin
{

    var $_plgCode = "#{janrain(.*?)}#i";
    var $_plgCodeHolder = "{RPX-HOLDER-%d}";
    var $_plgCodeModifier = "#{janrain(.*?)}#e";
    var $_plgCodeMakeHolder = "'{RPX-HOLDER-' . plgSystemJanrain::getCount() . '}'";


    /**
     * Constructor
     *
     * For php4 compatability we must not use the __constructor as a constructor for plugins
     * because func_get_args ( void ) returns a copy of all passed arguments NOT references.
     * This causes problems with cross-referencing necessary for the observer design pattern.
     *
     * @param	object	$subject The object to observe
     * @param	param	$config The Param in ja nrain plugin
     */
    function __construct(&$subject, $config)
    {
        parent::__construct($subject, $config);
        $this->plugin = &JPluginHelper::getPlugin('system', 'janrain');
        $this->plgParams = $this->params;

        /* Load Language file */
        $this->loadLanguage('plg_' . $this->plugin->type . '_' . $this->plugin->name, JPATH_ADMINISTRATOR);
    }


    /**
     *
     * Process task after Initialise
     * @return unknown
     */
    function onAfterInitialise()
    {

        if (!file_exists(JPATH_SITE . DS . 'plugins' . DS . 'system' . DS . 'janrain' . DS . 'install.complete')) {
            $db = & JFactory::getDBO();
            $query = "CREATE TABLE `#__jarpx_mapid` (`user_id` INT NOT NULL ,`rpxid` VARCHAR(50) NOT NULL);";
            $db->setQuery($query);
            $db->query();
            @file_put_contents('plugins/system/janrain/install.complete', date('r'));
        }

        //get token return from RPX service
        $returntoken = (JRequest::getVar("auth_token", "") != "") ? JRequest::getVar("auth_token", "") : JRequest::getVar("token", "");

        if ($returntoken !== "") {

            //get apikey
            $apiKey = $this->params->get("apikey");

            $data_post = array('token' => $returntoken, 'apiKey' => $apiKey, 'format' => 'json');

            //get user login info
            $authinfo = $this->get_Authinfo($data_post, $this->params->get("usecurl"));

            if ($authinfo['stat'] == "ok") {
                $db = & JFactory::getDBO();
                $rpxid = 'rpx' . md5($authinfo['profile']['identifier']);
                $query = "SELECT user_id FROM #__jarpx_mapid WHERE rpxid='" . $rpxid . "'";
                $db->setQuery($query);
                $userid = $db->loadResult();
                $createuser = true;

                if (isset($userid)) {

                    $query = "SELECT id FROM #__users WHERE id='" . $userid . "'";
                    $db->setQuery($query);
                    $uid = $db->loadResult();

                    if ($uid == $userid) {
                        //Get parameters
                        $userparam = new JParameter("");
                        foreach ($authinfo['profile'] as $keyu => $valueu) {
                            if (is_array($valueu)) {
                                foreach ($valueu as $keyu1 => $valueu1) {
                                    $userparam->set($keyu1, $valueu1);
                                }
                            } else {
                                $userparam->set($keyu, $valueu);
                            }
                        }
                        $user = new JUser($uid);
                        $user->set("_params", $userparam);
                        $user->save();
                        $createuser = false;
                        $username = $user->get("username");
                    } else {

                        $query = "DELETE FROM #__jarpx_mapid WHERE user_id='" . $userid . "'";
                        $db->setQuery($query);
                        $db->query();

                    }
                }
				
				$register_details = array();
				isset($authinfo['profile']['displayName']) ? ($displayName = $authinfo['profile']['displayName']) : ($displayName = $authinfo['profile']['name']['displayName']);
				isset($authinfo['profile']['preferredUsername']) ? ($preferredUsername = $authinfo['profile']['preferredUsername']) : ($preferredUsername = $authinfo['profile']['name']['preferredUsername']);
				$usernameexits = true;
				$index = 0;

				$userName = $preferredUsername . "_" . $authinfo['profile']['providerName'];

				$salt = JUserHelper::genRandomPassword();
				$crypt = JUserHelper::getCryptedPassword("joomlart", $salt);
				$pwd = $crypt . ':' . $salt;
				$register_details['password'] = $pwd;
				if (isset($authinfo['profile']['email'])) {
					$register_details['email'] = $authinfo['profile']['email'];
				} else if (isset($authinfo['profile']['name']['email'])) {
					$register_details['email'] = $authinfo['profile']['name']['email'];
				} else {
					$uri = JFactory::getURI();
					$domain = substr($uri->getHost(), 4);
					$register_details['email'] = str_replace(" ", "_", $userName) . "@" . $domain;
				}

				$register_details['name'] = $displayName;
				$register_details['username'] = $userName;

				//Get parameters
				$userparam = new JParameter("");
				foreach ($authinfo['profile'] as $keyu => $valueu) {
					if (is_array($valueu)) {
						foreach ($valueu as $keyu1 => $valueu1) {
							$userparam->set($keyu1, $valueu1);
						}
					} else {
						$userparam->set($keyu, $valueu);
					}
				}

				$register_details['params'] = $userparam;

				$username = $userName;
				//if create new user
                if ($createuser) {
                    //resgister new user
                    if ($this->params->get("register", true)) {
                        $newuserid = $this->register_joomla($register_details, $authinfo);
                        if ($newuserid) {
                            $query = "INSERT INTO #__jarpx_mapid (user_id, rpxid) VALUES ('" . $newuserid . "','" . $rpxid . "')";
                            $db->setQuery($query);
                            if (!$db->query()) {
                                JERROR::raiseError(500, $db->stderror());
                            }
                        }

                    }

                }
                //login as a user of joomla
                $this->login_joomla($username, $register_details['email'], $register_details['name']);
            }
        } else {
            // stay on the same page
            if (!(isset($_SERVER['HTTP_X_REQUESTED_WITH']) && ($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest'))) {
                $uri = JFactory::getURI();
                $url = $uri->toString(array('path', 'query', 'fragment'));
                $ses = &JFactory::getSession();
                $ses->set("afterlogin", $url);
            }
        }
    }


    /**
     *
     * process body after rendered
     * @return unknown
     */
    function onAfterRender()
    {
        $mainframe = JFactory::getApplication();
        global $option;
        jimport("joomla.application.module.helper");

        if ($mainframe->isAdmin()) {
            return;
        }

        $body = JResponse::getBody();
        if (!preg_match($this->_plgCode, $body)) {
            return;
        }
        $this->_aUSetting = $this->getUserSetting($body);
        if (count($this->_aUSetting) > 0) {
            foreach ($this->_aUSetting as $id => $sSetting) {
                $pgparams = $this->parseParams($sSetting);
                $layout = "default";
                if (isset($pgparams) and is_array($pgparams)) {
                    foreach ($pgparams as $pa => $val) {
                        $this->params->set($pa, $val);
                    }
                }
                $output = $this->loadLayout($this->plugin, $layout);
                $holder = sprintf($this->_plgCodeHolder, $id);
                $body = str_replace($holder, $output, $body);
            }
        }
        JResponse::setBody($body);

    }


    /**
     *
     * get Count task
     * @param boolean $reset
     */
    function getCount($reset = false)
    {
        static $count = 0;
        if ($reset)
            $count = -1;
        return $count++;
    }


    /**
     *
     * get user setting
     * @param string $text
     * @return array
     */
    function getUserSetting(&$text)
    {
        if (preg_match_all($this->_plgCode, $text, $matches)) {
            $text = preg_replace($this->_plgCodeModifier, $this->_plgCodeMakeHolder, $text, -1, $count);
            return $matches[1];
        } else {
            return array();
        }

    }


    /**
     *
     * get layout
     * @param object $plugin
     * @param string $layout
     * @return	string
     */
    function getLayoutPath($plugin, $layout = 'default')
    {
        $mainframe = JFactory::getApplication();

        // Build the template and base path for the layout
        $tPath = JPATH_BASE . DS . 'templates' . DS . $mainframe->getTemplate() . DS . 'html' . DS . $plugin->name . DS . $layout . '.php';
        $bPath = JPATH_BASE . DS . 'plugins' . DS . $plugin->type . DS . $plugin->name . DS . 'tmpl' . DS . $layout . '.php';
        // If the template has a layout override use it
        if (file_exists($tPath)) {
            return $tPath;
        } elseif (file_exists($bPath)) {
            return $bPath;
        }
        return '';
    }


    /**
     *
     * load layout for display
     * @param object $plugin
     * @param string $layout
     * @return	string	conent
     */
    function loadLayout($plugin, $layout = 'default')
    {
        $layout_path = $this->getLayoutPath($plugin, $layout);
        if ($layout_path) {
            ob_start();
            require $layout_path;
            $content = ob_get_contents();
            ob_end_clean();
            return $content;
        }
        return '';
    }


    /**
     *
     * parse params
     * @param string $string
     * @return array params
     */
    function parseParams($string)
    {
        $string = html_entity_decode($string, ENT_QUOTES);
        $regex = "/\s*([^=\s]+)\s*=\s*('([^']*)'|\"([^\"]*)\"|([^\s]*))/";
        $params = null;
        if (preg_match_all($regex, $string, $matches)) {
            for ($i = 0; $i < count($matches[1]); $i++) {
                $key = $matches[1][$i];
                $value = $matches[3][$i] ? $matches[3][$i] : ($matches[4][$i] ? $matches[4][$i] : $matches[5][$i]);
                $params[$key] = $value;
            }
        }
        return $params;
    }


    /**
     *
     * get authorise
     * @param array $datapost
     * @param boolean $iscurl
     * @return unknown
     */
    function get_Authinfo($datapost, $iscurl)
    {

        if ($iscurl && function_exists('curl_init')) {
            $curl = curl_init();
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_URL, 'https://rpxnow.com/api/v2/auth_info/?token=' . $datapost['token'] . '&&apiKey=' . $datapost['apiKey'] . '&&format=json');
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $datapost);
            curl_setopt($curl, CURLOPT_HEADER, false);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            $raw_json = curl_exec($curl);
            curl_close($curl);

        } else if (ini_get('allow_url_fopen') && extension_loaded("openssl")) {
            $host = "rpxnow.com";
            $path = "/api/v2/auth_info/";
            $req = "&token=" . $datapost['token'] . "&apiKey=" . $datapost['apiKey'] . "&format=json";
            $raw_json = @file_get_contents("https://rpxnow.com/api/v2/auth_info/?token=" . $datapost['token'] . "&&apiKey=" . $datapost['apiKey'] . "&&format=json");

        } else {
            JError::raiseWarning(1, JText::_('Sorry, but your server does not currently support curl  or openssl extension to use Janrain plugin. Please contact your hosting manager for help') . '.');
            return;
        }

        //parse the json response into an associative array
        if (function_exists("json_decode")) {
            $authinfo = json_decode($raw_json, true);
        } else {
            require_once (JPATH_ROOT . "/plugins/system/janrain/JSON.php");
            $json = new Services_JSON(SERVICES_JSON_LOOSE_TYPE);
            $authinfo = $json->decode($raw_json);
        }

        return $authinfo;
    }


    /**
     *
     * register a user to joomla
     * @param array $register_details
     * @param object $user_details
     * @return	int user id
     */
    function register_joomla($register_details, $user_details)
    {
        $db = & JFactory::getDBO();
        $mainframe = JFactory::getApplication();
        // Get required system objects
        $user = new JUser();
        $authorize = & JFactory::getACL();
        $app = JFactory::getApplication();
        $params = JComponentHelper::getParams('com_users');

        // Override the base user data with any data in the session.
        $temp = (array) $app->getUserState('com_users.registration.data', array());
        $data = array();
        foreach ($temp as $k => $v) {
            $data[$k] = $v;
        }
        // If user registration is not allowed, show 403 not authorized.
        $usersConfig = &JComponentHelper::getParams('com_users');
        // Initialize new usertype setting
        $newUsertype = $usersConfig->get('new_usertype', 2);
        // Get the default new user group, Registered if not specified.
        // Set some initial user values
        //$user->set('id', 0);
        $data['usertype'] = '';
        $data['groups'] = array($newUsertype);
        $date = & JFactory::getDate();
        $data['registerDate'] = $date->toMySQL();
        $data['name'] = ($register_details['name'] ? $register_details['name'] : $register_details['username']);
        $data['username'] = $register_details['username'];
        $data['email'] = $register_details['email'];
        $data['password'] = $register_details['password'];
        $data['password2'] = $register_details['password'];
        $data['_params'] = $register_details['params'];
        $data['block'] = '0';
        $data['activation'] = '';
        // Bind the data.
        if (!$user->bind($data)) {
            $this->setError(JText::sprintf('COM_USERS_REGISTRATION_BIND_FAILED', $user->getError()));
            return false;
        }
        // If there was an error with registration, set the message and display form
        if (!$user->save()) {
            JError::raiseWarning('', JText::_($user->getError()));
            return false;
        }
        return $user->id;
    }


    /**
     *
     * display login form
     * @param string $username
     * @return	unknown
     */
    function login_joomla($username, $email, $name = '')
    {

        $mainframe = JFactory::getApplication();
        // Get the global JAuthentication object.
        jimport('joomla.user.authentication');
        JPluginHelper::importPlugin('user');
        $authenticate = & JAuthentication::getInstance();
        $authenticate_response = new JAuthenticationResponse();
        $authenticate_response->status = JAUTHENTICATE_STATUS_SUCCESS;

        //set default options
        $option = array();
        $option['action'] = 'core.login.site';
        $option['group'] = 'USERS';
        $option['remember'] = '';
        $option['return'] = '';
        $option['entry_url'] = '';
        $option['autoregister'] = $this->params->get("register", true);
        //we need only username to login
        $authenticate_response->fullname = $name;
        $authenticate_response->username = $username;
        $authenticate_response->email = $email;

        $results = $mainframe->triggerEvent('onUserLogin', array((array) $authenticate_response, $option));

        $returnURL = $this->get_ReturnURL();
        $data = array();
        $data['return'] = base64_decode($returnURL);
        $data['username'] = $username;

        // Set the return URL if empty.
        if (empty($data['return'])) {
            $data['return'] = 'index.php?option=com_users&view=profile';
        }
        // Check if the log in succeeded.
        if (!JError::isError($results)) {
            $mainframe->setUserState('users.login.form.data', array());
            $mainframe->redirect(JRoute::_($data['return'], false));
        } else {
            $data['remember'] = false;
            $mainframe->setUserState('users.login.form.data', $data);
            $mainframe->redirect(JRoute::_('index.php?option=com_users&view=login', false));
        }

    }


    /**
     *
     * get url return after logout
     * @return string url
     */
    function get_ReturnURL()
    {
        $itemid = $this->params->get('logout');
        if ($itemid) {

            $menu = & JSite::getMenu();
            $item = $menu->getItem($itemid);
            $url = JRoute::_($item->link . '&Itemid=' . $itemid, false);
        } else {
            $uri = JFactory::getURI();
            $url = $uri->current();
            $url .= '?';
            $paramarray = $uri->getQuery(true);

            foreach ($paramarray as $paramname => $paramvalue) {
                if ($paramname != 'token') {
                    $url .= $paramname;
                    $url .= '=';
                    $url .= $paramvalue;
                    $url .= '&';
                }
            }
			$url = substr($url, 0, (strrpos($url, "&"))?strrpos($url, "&"):strrpos($url, "?"));

        }
        return base64_encode($url);
    }


    /**
     *
     * get module params
     * @return string content param
     */
    public function loadModuleParams()
    {
        $arr_params = array();
        $arr_params["pretext"] = "";
        $arr_params["posttext"] = "";
        $arr_params["logout"] = $this->params->get("logout", "");
        $arr_params["greeting"] = $this->params->get("greeting", 0);
        $arr_params["name"] = $this->params->get("name", 0);
        $arr_params["usesecure"] = $this->params->get("usesecure", 0);
        $content_params = "";
        foreach ($arr_params as $key => $value) {
            if (!empty($value)) {
                $content_params .= $key . "=" . $value . "\n";
            }
        }
        return $content_params;
    }


    /**
     *
     * Load module login
     */
    public function getModuleLogin()
    {
        $modules = $this->loadModules();
        $module = null;
        if (!empty($modules)) {
            foreach ($modules as $key => &$item) {
                // Match the name of the module
                if ($item->name == "login") {
                    $module = &$item;
                    break; // Found it
                }
            }
        }
        $module->showtitle = 0;
        $module->content = null;
        if (isset($module) && @$module->id) {
            $module->params = $this->loadModuleParams();
            return JModuleHelper::renderModule($module);
        }
        return "";
    }


    /**
     * Load published modules
     *
     * @return	array
     */
    public function loadModules()
    {
        $clean = array();

        $Itemid = JRequest::getInt('Itemid');
        $app = JFactory::getApplication();
        $user = JFactory::getUser();
        $groups = implode(',', $user->getAuthorisedViewLevels());
        $db = JFactory::getDBO();

        $query = $db->getQuery(true);
        $query->select('id, title, module, position, content, showtitle, params, mm.menuid');
        $query->from('#__modules AS m');
        $query->join('LEFT', '#__modules_menu AS mm ON mm.moduleid = m.id');
        $query->where('m.published = 1');

        $date = JFactory::getDate();
        $now = $date->toMySQL();
        $nullDate = $db->getNullDate();
        $query->where('(m.publish_up = ' . $db->Quote($nullDate) . ' OR m.publish_up <= ' . $db->Quote($now) . ')');
        $query->where('(m.publish_down = ' . $db->Quote($nullDate) . ' OR m.publish_down >= ' . $db->Quote($now) . ')');

        $clientid = (int) $app->getClientId();

        if (!$user->authorise('core.admin', 1)) {
            $query->where('m.access IN (' . $groups . ')');
        }
        $query->where('m.client_id = ' . $clientid);

        $query->order('position, ordering');

        // Filter by language
        if ($app->isSite() && $app->getLanguageFilter()) {
            $query->where('m.language in (' . $db->Quote(JFactory::getLanguage()->getTag()) . ',' . $db->Quote('*') . ')');
        }

        // Set the query
        $db->setQuery($query);

        $cache = JFactory::getCache('com_modules', 'callback');
        $cacheid = md5(serialize(array($Itemid, $groups, $clientid, JFactory::getLanguage()->getTag())));

        $modules = $cache->get(array($db, 'loadObjectList'), null, $cacheid, false);
        if (null === $modules) {
            JError::raiseWarning('SOME_ERROR_CODE', JText::sprintf('JLIB_APPLICATION_ERROR_MODULE_LOAD', $db->getErrorMsg()));
            $return = false;
            return $return;
        }

        // Apply negative selections and eliminate duplicates
        $negId = $Itemid ? -(int) $Itemid : false;
        $dupes = array();
        $clean = array();
        for ($i = 0, $n = count($modules); $i < $n; $i++) {
            $module = &$modules[$i];

            // The module is excluded if there is an explicit prohibition, or if
            // the Itemid is missing or zero and the module is in exclude mode.
            $negHit = ($negId === (int) $module->menuid) || (!$negId && (int) $module->menuid < 0);

            if (isset($dupes[$module->id])) {
                // If this item has been excluded, keep the duplicate flag set,
                // but remove any item from the cleaned array.
                if ($negHit) {
                    unset($clean[$module->id]);
                }
                continue;
            }
            $dupes[$module->id] = true;

            // Only accept modules without explicit exclusions.
            if (!$negHit) {
                //determine if this is a custom module
                $file = $module->module;
                $custom = substr($file, 0, 4) == 'mod_' ? 0 : 1;
                $module->user = $custom;
                // Custom module name is given by the title field, otherwise strip off "com_"
                $module->name = $custom ? $module->title : substr($file, 4);
                $module->style = null;
                $module->position = strtolower($module->position);
                $clean[$module->id] = $module;
            }
        }
        unset($dupes);
        // Return to simple indexing that matches the query order.
        $clean = array_values($clean);

        return $clean;
    }
}

?>