<?php
/**
 * ------------------------------------------------------------------------
 * JA System Nrain Plugin for Joomla 2.5
 * ------------------------------------------------------------------------
 * Copyright (C) 2004-2011 J.O.O.M Solutions Co., Ltd. All Rights Reserved.
 * @license - GNU/GPL, http://www.gnu.org/licenses/gpl.html
 * Author: J.O.O.M Solutions Co., Ltd
 * Websites: http://www.joomlart.com - http://www.joomlancers.com
 * ------------------------------------------------------------------------
 */

defined('_JEXEC') or die('Restricted access');

if ($this->params->get('japretext')) {
?>
<div class="pretext"><?php echo $this->params->get('japretext');?></div>
<?php }?>
<?php

if ($this->params->get('showlogin') == 1) {
    echo $this->getModuleLogin();
}

$usecurl = $this->params->get('usecurl', 1);
$api_key = $this->params->get('apikey');
$user = & JFactory::getUser();
$type = (!$user->get('guest')) ? 'logout' : 'login';
$return = $this->get_ReturnURL();

if ($type == "login") {

    if (!$api_key) {
        echo JText::_('Please setting API Key...');
        return;
    }

    $post_data = array('apiKey' => $api_key);

    if (function_exists('curl_init')) {

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_URL, 'https://rpxnow.com/plugin/lookup_rp');
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $post_data);
        curl_setopt($curl, CURLOPT_HEADER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        $raw_json = curl_exec($curl);
        curl_close($curl);

    } else if (ini_get('allow_url_fopen') && extension_loaded("openssl")) {

        $raw_json = @file_get_contents("https://rpxnow.com/plugin/lookup_rp?apiKey=" . $post_data['apiKey'] . "&&format=json");

    } else {

        JError::raiseWarning(1, JText::_('Sorry, but your server does not currently support open method. Please contact the network administrator system for help') . '.');
        return;
    }

    // parse the json response into an associative array
    $json = json_decode($raw_json, true);

    $realm = $json['realm'];
    //$realm = "dathq-test.rpxnow.com";
    $tokenurl = JURI::base();

    ?>

<div style="position: relative; left: 15px">
<p><?php
if ($this->params->get('showlogin') == 1)
echo 'OR'?> <?php
echo JText::_('Login with your');
?></p>
<input type="hidden" name="apiKey"
	value="<?php
    echo $api_key;
    ?>" /> <a class="rpxnow" style="text-decoration: none"
	onclick="return false;"
	href="https://<?php
    echo $realm;
    ?>/openid/v2/signin?token_url=<?php
    echo $tokenurl;
    ?>"> <img width="55" src="plugins/system/janrain/images/google.png"
	alt="RPX" /> </a> <a class="rpxnow" style="text-decoration: none"
	onclick="return false;"
	href="https://<?php
    echo $realm;
    ?>/openid/v2/signin?token_url=<?php
    echo $tokenurl;
    ?>"> <img width="55" src="plugins/system/janrain/images/twitter.png"
	alt="RPX" /> </a> <a class="rpxnow" style="text-decoration: none"
	onclick="return false;"
	href="https://<?php
    echo $realm;
    ?>/openid/v2/signin?token_url=<?php
    echo $tokenurl;
    ?>"> <img style="position: relative; top: 2px" width="55"
	src="plugins/system/janrain/images/openid.png" alt="RPX" /> </a> <a
	class="rpxnow" style="text-decoration: none" onclick="return false;"
	href="https://<?php
    echo $realm;
    ?>/openid/v2/signin?token_url=<?php
    echo $tokenurl;
    ?>"> <img style="position: relative; top: 2px" width="55"
	src="plugins/system/janrain/images/spacel.png" alt="RPX" /> </a> <a
	class="rpxnow" style="text-decoration: none" onclick="return false;"
	href="https://<?php
    echo $realm;
    ?>/openid/v2/signin?token_url=<?php
    echo $tokenurl;
    ?>"> <img width="55" src="plugins/system/janrain/images/login.png"
	alt="RPX" /> </a> <a class="rpxnow" style="text-decoration: none"
	onclick="return false;"
	href="https://<?php
    echo $realm;
    ?>/openid/v2/signin?token_url=<?php
    echo $tokenurl;
    ?>"> <img style="position: relative; top: 2px" width="55"
	src="plugins/system/janrain/images/facebook.png" alt="RPX" /> </a></div>

    <?php   if ($this->params->get('japosttext')) {?>
<div class="posttext"><?php   echo $this->params->get('japosttext');?></div>
    <?php }?>

<script
	src="https://rpxnow.com/openid/v2/widget" type="text/javascript"></script>

<script type="text/javascript">
  RPXNOW.token_url = "<?php
    echo $tokenurl?>";
  RPXNOW.realm = "<?php
    echo $realm;
    ?>";
  RPXNOW.overlay = true;
  RPXNOW.default_provider = "openid";
  RPXNOW.language_preference = 'en';
  RPXNOW.flags="show_provider_list";
  RPXNOW.flags="hide_sign_in_with";
</script>

    <?php
} else {
    if ($this->params->get('showlogin') == 0) {
        $user = JFactory::getUser();
        ?>
<form action="index.php" method="post" name="form-login" id="login-form">
        <?php
        if ($this->params->get('greeting', 1) == 1) :
        ?>
<div class="login-greeting"><?php
if ($this->params->get('name') == 0) :
{
    echo JText::sprintf('MOD_LOGIN_HINAME', $user->get('name'));
}
else :
{
    echo JText::sprintf('MOD_LOGIN_HINAME', $user->get('username'));
}
endif;
?></div>


<?php endif;
?>
<div class="logout-button"><input type="submit" name="Submit"
	class="button"
	value="<?php
        echo JText::_('JLOGOUT');
        ?>" /></div>

<input type="hidden" name="option" value="com_users" /> <input
	type="hidden" name="task" value="user.logout" /> <input type="hidden"
	name="return" value="<?php
        echo $return;
        ?>" /></form>
        <?php
    }
    ?>
    <?php

    if ($this->params->get('japosttext')) {
        ?>
<div class="posttext"><?php
echo $this->params->get('japosttext');
?></div>
<?php
    }
    ?>
    <?php
}
?>