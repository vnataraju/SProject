<?php
/**
 * ------------------------------------------------------------------------
 * JA Search Comment Plugin for Joomla J2.5
 * ------------------------------------------------------------------------
 * Copyright (C) 2004-2011 J.O.O.M Solutions Co., Ltd. All Rights Reserved.
 * @license - GNU/GPL, http://www.gnu.org/licenses/gpl.html
 * Author: J.O.O.M Solutions Co., Ltd
 * Websites: http://www.joomlart.com - http://www.joomlancers.com
 * ------------------------------------------------------------------------
 */

// no direct access
defined( '_JEXEC' ) or die;

jimport('joomla.plugin.plugin');

/**
 * JAComments Search plugin
 *
 * @package		Joomla
 * @subpackage	Search
 * @since		1.6
 */
class plgSearchSearch_JAComment extends JPlugin
{
	public function __construct(&$subject, $config)
	{
		parent::__construct($subject, $config);
		$this->loadLanguage();
	}
	
	/**
	 * @return array An array of search areas
	 */
	function onContentSearchAreas()
	{
		static $areas = array(
			'JAComment' => 'JA Comment'
		);
		return $areas;
	}

	/**
	 * JAComment Search method
	 *
	 * The sql must return the following fields that are
	 * used in a common display routine: href, title, section, created, text,
	 * browsernav
	 * @param string Target search string
	 * @param string mathcing option, exact|any|all
	 * @param string ordering option, newest|oldest|popular|alpha|category
	 * @param mixed An array if restricted to areas, null if search all
	 */
	function onContentSearch( $text, $phrase='', $ordering='', $areas=null )
	{
		$db		=& JFactory::getDBO();
		$user	=& JFactory::getUser();
		$searchText = $text;

		require_once(JPATH_SITE.DS.'components'.DS.'com_content'.DS.'helpers'.DS.'route.php');

		if (is_array( $areas )) {
			if (!array_intersect( $areas, array_keys( $this->onContentSearchAreas() ) )) {
				return array();
			}
		}

		$limit = $this->params->def('search_limit', 50);

		$text = trim( $text );
		if ( $text == '' ) {
			return array();
		}

		switch ( $ordering ) {
			case 'alpha':
				$order = 'a.name ASC';
				break;

			case 'category':
			case 'popular':
			case 'newest':
			case 'oldest':
			default:
				$order = 'a.name DESC';
		}

		$text	= $db->Quote( '%'.$db->getEscaped( $text, true ).'%', false );
		$query	= 'SELECT a.name AS title, a.comment AS text, a.date AS created,'
		. ' "2" AS browsernav,'
		. ' a.referer'
		. ' FROM #__jacomment_items a'
		. ' WHERE ( a.name LIKE '.$text
		. ' OR contenttitle LIKE '.$text
		. ' OR a.comment LIKE '.$text.' )'
		. ' AND a.type = 1'
		. ' ORDER BY '. $order
		;
		$db->setQuery( $query, 0, $limit );	
		$rows = $db->loadObjectList();
		
		$return = array();
		if ($rows) {
			foreach($rows as $key => $row) {
				$rows[$key]->href = JURI::base(true) . "/" . ($rows[$key]->referer);
				$rows[$key]->section = JText::_( 'JA Comment' );
			}

			foreach($rows AS $key => $val) {
				if (searchHelper::checkNoHTML($val, $searchText, array('name', 'title', 'text'))) {
					$return[] = $val;
				}
			}
		}

		return $return;
	}
}