/**
 * ------------------------------------------------------------------------
 * JA Comment Off Plugin for Joomla 2.5
 * ------------------------------------------------------------------------
 * Copyright (C) 2004-2011 J.O.O.M Solutions Co., Ltd. All Rights Reserved.
 * @license - GNU/GPL, http://www.gnu.org/licenses/gpl.html
 * Author: J.O.O.M Solutions Co., Ltd
 * Websites: http://www.joomlart.com - http://www.joomlancers.com
 * ------------------------------------------------------------------------
 */
function insertJaCommentOn(editor, editorContent) {
	var content = editorContent;
	if (content.match(/{jacomment on}/)) {
		content.replace('{jacomment on}', '');
	}
	if (content.match(/{jacomment off}/)) {
		return false;
	} else {
		jInsertEditorText('{jacomment off}', editor);
	}
}