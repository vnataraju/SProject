<?php
/**
 * ------------------------------------------------------------------------
 * JA Latest Comment Module for Joomla 2.5
 * ------------------------------------------------------------------------
 * Copyright (C) 2004-2011 J.O.O.M Solutions Co., Ltd. All Rights Reserved.
 * @license - GNU/GPL, http://www.gnu.org/licenses/gpl.html
 * Author: J.O.O.M Solutions Co., Ltd
 * Websites: http://www.joomlart.com - http://www.joomlancers.com
 * ------------------------------------------------------------------------
 */
// no direct access
defined('_JEXEC') or die('Restricted access');
/**
 *
 * JA COMPONENT FETCH ELEMENT
 * @author Administrator
 *
 */
class JFormFieldJAComponent extends JFormField
{
    /**
     * @access private
     */
    protected $type = 'jacomponent';


    /**
     *
     * Get input
     */
    protected function getInput()
    {
        $db = &JFactory::getDBO();

        $tmpComponents = JFormFieldJAComponent::getComponentListFromFolder(JPATH_SITE . DS . 'components');

		$query = "(SELECT element FROM #__extensions
					WHERE protected=0 AND element NOT IN ('com_content', 'com_jacomment') AND element IN ('" . implode("','", $tmpComponents) . "'))
				  UNION
				  (SELECT 'com_content' AS element)
				  ORDER BY element";
		$db->setQuery($query);
        $components = $db->loadObjectList();

        $mitems = array();
        $mitems[] = JHTML::_('select.option', '', '-- ' . JText::_('ALL_COMPONENTS') . ' --');
        foreach ($components as $item) {
            $mitems[] = JHTML::_('select.option', $item->element, $item->element);
        }

        $output = JHTML::_('select.genericlist', $mitems, $this->name, 'class="inputbox" multiple="multiple" size="10"', 'value', 'text', $this->value);

        return $output;
    }


    /**
     *
     * Get list component from a folder
     * @param string $folder
     * @return array
     */
    function getComponentListFromFolder($folder)
    {
        if (is_dir($folder)) {
            $components = JFolder::folders($folder);
        }

        return $components;
    }
}