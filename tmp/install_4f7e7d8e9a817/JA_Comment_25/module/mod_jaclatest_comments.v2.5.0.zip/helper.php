<?php
/**
 * ------------------------------------------------------------------------
 * JA Latest Comment Module for Joomla 2.5
 * ------------------------------------------------------------------------
 * Copyright (C) 2004-2011 J.O.O.M Solutions Co., Ltd. All Rights Reserved.
 * @license - GNU/GPL, http://www.gnu.org/licenses/gpl.html
 * Author: J.O.O.M Solutions Co., Ltd
 * Websites: http://www.joomlart.com - http://www.joomlancers.com
 * ------------------------------------------------------------------------
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

require_once (JPATH_SITE . DS . 'components' . DS . 'com_jacomment' . DS . 'models' . DS . 'comments.php');
require_once (JPATH_SITE . DS . 'components' . DS . 'com_jacomment' . DS . 'helpers' . DS . 'jahelper.php');
/**
 *
 * JA LATEST COMMENTS HELPER CLASS
 * @author JoomlArt
 *
 */
class modJACLatestItemsHelper
{
    /**
     * Get list comments
     *
     * @param object $params
	 * 
     * @return array
     */
    function getList(&$params)
    {
        $source = $params->get("type", "");
        $items = array();

        $order = '';
        $type = $params->get("sort_type", 1);
        if ($type == "1") {
            $order = " id";
        } else {
            $order = " voted";
        }

        $count = $params->get("count", 1);

        $items = modJACLatestItemsHelper::getLatestFromComponent($params, $source, $order, $count);

        return $items;
    }

    /**
     * Build query get list comment for article joomla
     *
     * @param object $params
     * @param string $source
	 * 
     * @return string
     */
    function getLatestFromContent($params, $source)
    {
        $queryContent = '';
        if ($source[0] == '' || in_array('com_content', $source)) {
            // generate query for com_content
            $content_category = $params->get("type-com_content-content_category", array());

            $where = "cm2.type = 1";
            $where .= " AND cm2.option = 'com_content'";
            $where .= " AND c.state != -2 AND c.state != 0";

            if (!is_array($content_category)) {
                $content_category = array($content_category);
            }

            if (count($content_category)) {
                $where .= " AND c.catid IN (" . implode(',', $content_category) . ")";
            }

			$queryContent = "SELECT cm2.*, c.title AS content_title FROM #__jacomment_items cm2"
						. "\n LEFT JOIN #__content c ON cm2.contentid = c.id"
						. "\n WHERE {$where}";
		}

        return $queryContent;
    }

    /**
     * Build query get list comment for article joomla
	 * 
     * @param object $params
     * @param string $source
	 * 
     * @return string
	 */	
	function getLatestFromK2($params, $source)
	{
		$db = JFactory::getDBO();
		
		$queryK2 = '';
		if ($source[0] == '' || in_array('com_k2', $source)) {
		// generate query for com_k2
			$k2_category = $params->get("type-com_content-k2_category", array());
			
			$where = "cm3.type = 1";
			$where .= " AND cm3.option = 'com_k2'";
			$where .= " AND i.published = 1";
			
			if (!is_array($k2_category)) {
				$k2_category = array($k2_category);
			}
			
			if (empty($k2_category) || trim($k2_category[0]) == '') {
				$query = "SELECT COUNT(*) FROM #__extensions WHERE element ='com_k2'";
				$db->setQuery($query);
				if ($db->loadResult()) {
					$query = "SELECT id FROM #__categories";
					$db->setQuery($query);
					$cats = $db->loadObjectList();
					if (! $cats) {
						return '';
					}
					else {
						foreach ($cats as $cat) {
							$k2_category[] = $cat->id;
						}
					}
				}
				else {
					return '';
				}
			}
			
			if (count($k2_category)) {
				// remove empty element from k2_category
				$k2_category = array_diff($k2_category, array(''));
				
				$where .= " AND i.catid IN (" . implode(',', $k2_category) . ")";
			}
			
			$queryK2 = "SELECT cm3.*, i.title AS content_title FROM #__jacomment_items cm3"
						. "\n LEFT JOIN #__k2_items i ON cm3.contentid = i.id"
						. "\n WHERE {$where}";
		}
		
		return $queryK2;
	}

    /**
     * Build query get list comment for component joomla
     *
     * @param object $params
     * @param string $source
	 * 
     * @return string
     */
    function getLatestFromComponent($params, $source, $order, $count)
    {
        $db = JFactory::getDBO();

        if (!is_array($source)) {
            $source = array($source);
        }

        $queryContent = modJACLatestItemsHelper::getLatestFromContent($params, $source);

		$queryK2 = modJACLatestItemsHelper::getLatestFromK2($params, $source);
		
        $where = "cm1.type = 1";

        if ($source[0] == '') {
		// select all components
			if ($queryK2 == '') {
				$query = "(SELECT cm1.*, '' AS content_title FROM #__jacomment_items cm1 WHERE {$where} AND cm1.option <> 'com_content')
						  UNION
						  ({$queryContent})";
			}
			else {
				$query = "(SELECT cm1.*, '' AS content_title FROM #__jacomment_items cm1 WHERE {$where} AND cm1.option NOT IN ('com_content', 'com_k2'))
						  UNION
						  ({$queryContent})
						  UNION 
						  ({$queryK2})";
			}
		} else if (count($source) == 1 && $source[0] == 'com_content') {
            // only select com_content
            $query = $queryContent;
		} else if (count($source) == 1 && $source[0] == 'com_k2') {
		// only select com_k2
			$query = $queryK2;
        } else {
            // select some of components
		
            // remove 'com_content' from source
			$source = array_diff($source, array('com_content', 'com_k2'));

			$query = "(SELECT cm1.*, '' AS content_title FROM #__jacomment_items cm1"
					. "\n WHERE {$where} AND cm1.option IN ('" . implode("','", $source) . "'))";

            if ($queryContent != '') {
                $query .= " UNION ({$queryContent})";
            }
			
			if ($queryK2 != '') {
				$query .= " UNION ({$queryK2})";
			}
        }

        $query .= " ORDER BY {$order} DESC LIMIT " . intval($count);

        $db->setQuery($query);
        return $db->loadObjectList();
    }


    /*
	 * get avatar, author info, content, title
	 */
    function parseItems($params, &$items)
    {
        $helperSub = new JACSmartTrim();
        $helperCom = new JACommentHelpers();
        $typeAvatar = 0;
        require_once (JPATH_BASE . DS . 'components' . DS . 'com_jacomment' . DS . 'models' . DS . 'comments.php');
        $model = new JACommentModelComments();
        $typeAvatar = $model->getParamValue("layout", "type_avatar", 0);
        if (!$items)
            return;
        foreach ($items as &$item) {
            if ($params->get("showcontent", 1)) {
				if ($params->get("length", 50) == 0) {
					$item->comment = '';
				} else {
					//$item->comment = html_entity_decode($helper->replaceBBCodeToHTML($item->comment));
					$item->comment = html_entity_decode($helperCom->showComment($helperCom->replaceBBCodeToHTML($item->comment, $params->get("showbbcode", 1), 1), true, $params->get("showsmiles", 1),'100%'));
					$item->comment = $helperSub->mb_trim($item->comment, 0, $params->get("length", 50));
				}
            }

            if ($params->get("show_content_title", 1)) {
                $item->contenttitle = empty($item->content_title) ? $item->contenttitle : $item->content_title;
                $item->contenttitle = $helperSub->mb_trim($item->contenttitle, 0, $params->get("limit_content_title", 50));
            }
            if ($params->get("avatar", "1")) {
                $item->avatar = JACommentHelpers::getAvatar($item->userid, 1, $params->get("avatar_size", 32), $typeAvatar, $item->email);
            }
            $author_info = $params->get("show_author_info", 1);
            if ($author_info) {
                //show real name
                $userInfo = JFactory::getUser($item->userid);
                if ($userInfo->id == 0) {
                    if ($author_info == "3") {
                        $item->author_info = $item->email;
                    } else {
                        $item->author_info = $item->name;
                    }
                } else {
                    if ($author_info == "1") {
                        $item->author_info = $userInfo->name;
                    } else if ($author_info == "2") {
                        $item->author_info = $userInfo->username;
                    } else {
                        $item->author_info = $userInfo->email;
                    }
                }

                if ($item->website && stristr($item->website, 'http://') === FALSE) {
                    $item->author_info = "<a href='http://{$item->website}'/>" . $item->author_info . "</a>";
                } else {
                    $item->author_info = $item->author_info;
                }
            }
            if ($params->get("show_date", 1) == 2) {
                $item->date = $helperCom->generatTimeStamp(strtotime($item->date));
            } else {
				$createDay = date('d', strtotime($item->date));
				$createMonth = JText::_(strtoupper(date('F', strtotime($item->date)))."_SHORT");
				$createYear = date('Y', strtotime( $item->date));
				
				$item->date = $createDay . ' ' . $createMonth . ' ' . $createYear;
            }
            if ($params->get("showcommentcount", 1)) {
                $search = '';
                $search .= ' AND c.option="' . $item->option . '"';
                $search .= ' AND c.contentid=' . $item->contentid . '';

                $totalType = $model->getTotalByType($search);

                $item->commentcount = (int) array_sum($totalType);
            }

            if (strpos($item->referer, "http://") === false) {
                // ++ Edited NhatNX on 20110509
				// ++ Edited Vutd on 20120323
                //$item->referer = JURI::base() . $item->referer;

				$url = explode('#jacommentid',$item->referer);
				$jacommentid = '';
				if(count($url)>1){
					$jacommentid = '#jacommentid'.$url[1];
				}
	            if($item->option=='com_content'){
					require_once (JPATH_SITE.DS.'components'.DS.'com_content'.DS.'helpers'.DS.'route.php');
					$itemtcontent = JTable::getInstance('content');
					$itemtcontent->load($item->contentid);
					$slug = $itemtcontent->id.':'.$itemtcontent->alias;
					$item->referer = JRoute::_(ContentHelperRoute::getArticleRoute($slug, $itemtcontent->catid));
				}else if($item->option=='com_k2'){
					JTable::addIncludePath(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_k2'.DS.'tables');
					require_once (JPATH_SITE.DS.'components'.DS.'com_k2'.DS.'helpers'.DS.'route.php');
					$itemk2 = &JTable::getInstance('K2Item', 'Table');
					$itemk2->load($item->contentid);
					$categoryk2 = &JTable::getInstance('K2Category', 'Table');
					$categoryk2->load($itemk2->catid);
					$item->referer = urldecode(JRoute::_(K2HelperRoute::getItemRoute($itemk2->id.':'.urlencode($itemk2->alias), $itemk2->catid.':'.urlencode($categoryk2->alias))));
				}else{
					$item->referer = JRoute::_($url[0]);
				}
				if($jacommentid){
					$item->referer .= $jacommentid;
				}
     // -- Edited NhatNX on 20110509
            }
        }
    }


    /*
	 *
	 */
    function loadStyle($module)
    {
        $mainframe = JFactory::getApplication();
        //load style of module
        JHTML::stylesheet('modules/' . $module->module . '/assets/' . $module->module . '.css');

        require_once (JPATH_BASE . DS . 'components' . DS . 'com_jacomment' . DS . 'models' . DS . 'comments.php');
        $model = new JACommentModelComments();
        $enableSmileys = $model->getParamValue("layout", "enable_smileys", 1);
        $smiley = $model->getParamValue("layout", "smiley", "default");
        if ($enableSmileys && !defined("JACOMMENT_GLOBAL_CSS_SMILEY")) {
			$style = '
					/* This is dynamic style for smiley */
			       #jac-wrapper .plugin_embed .smileys,.jac-mod_content .smileys{
			            top: 17px;
			        	background:#ffea00;
			            clear:both;
			            height:84px;
			            width:105px;
			            padding:2px 1px 1px 2px !important;
			            position:absolute;
			            z-index:51;
			            -webkit-box-shadow:0 1px 3px #999;box-shadow:1px 2px 3px #666;-moz-border-radius:2px;-khtml-border-radius:2px;-webkit-border-radius:2px;border-radius:2px;
			        }
			        #jac-wrapper .plugin_embed .smileys li,.jac-mod_content .smileys li{
			            display: inline;
			            float: left;
			            height:20px;
			            width:20px;
			            margin:0 1px 1px 0 !important;
			            border:none;
			            padding:0
			        }
			        #jac-wrapper .plugin_embed .smileys .smiley,.jac-mod_content .smileys .smiley{
			            background: url('.JURI::base().'components/com_jacomment/asset/images/smileys/'.$smiley.'/smileys_bg.png) no-repeat;
			            display:block;
			            height:20px;
			            width:20px;
			        }
			        #jac-wrapper .plugin_embed .smileys .smiley:hover,.jac-mod_content .smileys .smiley:hover{
			            background:#fff;
			        }
			        #jac-wrapper .plugin_embed .smileys .smiley span, .jac-mod_content .smileys .smiley span{
			            background: url('.JURI::base().'components/com_jacomment/asset/images/smileys/'.$smiley.'/smileys.png) no-repeat;
			            display: inline;
			            float: left;
			            height:12px;
			            width:12px;
			            margin:0px;
			        }
			        #jac-wrapper .plugin_embed .smileys .smiley span span, .jac-mod_content .smileys .smiley span span{
			            display: none;
			        }
			        #jac-wrapper .comment-text .smiley {
			            font-family:inherit;
						font-size:100%;
						font-style:inherit;
						font-weight:inherit;
						text-align:justify;
			        }
			        #jac-wrapper .comment-text .smiley span, .jac-mod_content .smiley span{
			            background: url('.JURI::base().'components/com_jacomment/asset/images/smileys/'.$smiley.'/smileys.png) no-repeat scroll 0 0 transparent;
						display:inline;
						float:left;
						height:12px;
						margin:0px 1px;
						width:12px;
			        }
			        .comment-text .smiley span span,.jac-mod_content .smiley span span{
			            display:none;
			        }
			';

		    $doc = & JFactory::getDocument();
            $doc->addStyleDeclaration($style);
        }

        if (file_exists(JPATH_BASE . DS . 'templates/' . $mainframe->getTemplate() . '/css/' . $module->module . '.css')) {
            JHTML::stylesheet('.css', 'templates/' . $mainframe->getTemplate() . '/css/' . $module->module);
        }

        $lang = & JFactory::getLanguage();
        if ($lang->isRTL()) {
            if (file_exists(JPATH_BASE . DS . 'modules/mod_jaclatest_comments/assets/' . $module->module . '_rlt.css')) {
                JHTML::stylesheet('modules/mod_jaclatest_comments/assests/' . $module->module . '_rtl.css');
            }
            if (file_exists(JPATH_BASE . DS . 'templates/' . $mainframe->getTemplate() . '/css/' . $module->module . '_rtl.css')) {
                JHTML::stylesheet('templates/' . $mainframe->getTemplate() . '/css/' . $module->module . '_rtl.css');
            }
        }

        if (!defined('JACOMMENT_GLOBAL_CSS')) {
            $theme = JACommentModelComments::getParamValue("layout", "themes", "default");
            $session = &JFactory::getSession();

            if (JRequest::getVar("jacomment_theme", '')) {
                jimport('joomla.filesystem.folder');
                $themeURL = JRequest::getVar("jacomment_theme");

                if (JFolder::exists('components/com_jacomment/themes/' . $themeURL) || (JFolder::exists('templates/' . $mainframe->getTemplate() . '/html/com_jacomment/themes/' . $themeURL))) {
                    $theme = $themeURL;
                }
                $session->set('jacomment_theme', $theme);
            } else {
                if ($session->get('jacomment_theme', null)) {
                    $theme = $session->get('jacomment_theme', $theme);
                }
            }
            //add style for japopup
            if (file_exists('components/com_jacomment/asset/css/ja.popup.css')) {
                JHTML::stylesheet('components/com_jacomment/asset/css/' . 'ja.popup.css');
            }
            //override template for japopup in template
            if (file_exists(JPATH_BASE . DS . 'templates/' . $mainframe->getTemplate() . '/css/ja.popup.css')) {
                JHTML::stylesheet('templates/' . $mainframe->getTemplate() . '/css/' . 'ja.popup.css');
            }

            //add style for all componennt
            if (file_exists('components/com_jacomment/asset/css/ja.comment.css')) {
                JHTML::stylesheet('components/com_jacomment/asset/css/' . 'ja.comment.css');
            }
            //override for all component
            if (file_exists(JPATH_BASE . DS . 'templates/' . $mainframe->getTemplate() . '/css/ja.comment.css')) {
                JHTML::stylesheet('templates/' . $mainframe->getTemplate() . '/css/' . 'ja.comment.css');
            }

            //add style only IE for all component
            if (file_exists('components/com_jacomment/asset/css/ja.ie.php')) {
                JHTML::stylesheet('components/com_jacomment/asset/css/' . 'ja.ie.php');
            }
            if (file_exists(JPATH_BASE . DS . 'templates/' . $mainframe->getTemplate() . '/css/ja.ie.php')) {
                JHTML::stylesheet('templates/' . $mainframe->getTemplate() . '/css/' . 'ja.ie.php');
            }

            //add style of template for component
            if (file_exists('components/com_jacomment/themes/' . $theme . '/css/style.css')) {
                JHTML::stylesheet('components/com_jacomment/themes/' . $theme . '/css/' . 'style.css');
            }
            if (file_exists(JPATH_BASE . DS . 'templates' . DS . $mainframe->getTemplate() . DS . 'html' . DS . "com_jacomment" . DS . "themes" . DS . $theme . DS . "css" . DS . "style.css")) {
                JHTML::stylesheet('templates/' . $mainframe->getTemplate() . '/html/com_jacomment/themes/' . $theme . '/css/' . 'style.css');
            }

            if (file_exists(JPATH_BASE . DS . 'components/com_jacomment/themes/' . $theme . '/css/style.ie.css')) {
                JHTML::stylesheet('components/com_jacomment/themes/' . $theme . '/css/' . 'style_ie.css');
            }
            if (file_exists(JPATH_BASE . DS . 'templates' . DS . $mainframe->getTemplate() . DS . 'html' . DS . "com_jacomment" . DS . "themes" . DS . $theme . DS . "css" . DS . "style.ie.css")) {
                JHTML::stylesheet('templates/' . $mainframe->getTemplate() . '/html/com_jacomment/themes/' . $theme . '/css/' . 'style.ie.css');
            }
            //override for all component
            if (file_exists(JPATH_BASE . DS . 'templates/' . $mainframe->getTemplate() . '/css/ja.comment.css')) {
                JHTML::stylesheet('templates/' . $mainframe->getTemplate() . '/css/' . 'ja.comment.css');
            }

            if ($lang->isRTL()) {
                if (file_exists(JPATH_BASE . DS . 'components/com_jacomment/asset/css/ja.popup_rtl.css')) {
                    JHTML::stylesheet('components/com_jacomment/asset/css/' . 'ja.popup_rtl.css');
                }
                if (file_exists(JPATH_BASE . DS . 'templates/' . $mainframe->getTemplate() . '/css/ja.popup_rtl.css')) {
                    JHTML::stylesheet('templates/' . $mainframe->getTemplate() . '/css/' . 'ja.popup_rtl.css');
                }
                if (file_exists(JPATH_BASE . DS . 'components/com_jacomment/asset/css/ja.comment_rtl.css')) {
                    JHTML::stylesheet('components/com_jacomment/asset/css/' . 'ja.comment_rtl.css');
                }
                if (file_exists(JPATH_BASE . DS . 'templates/' . $mainframe->getTemplate() . '/css/ja.comment_rtl.css')) {
                    JHTML::stylesheet('templates/' . $mainframe->getTemplate() . '/css/' . 'ja.comment_rtl.css');
                }

                //add style only IE for all component
                if (file_exists(JPATH_BASE . DS . 'components/com_jacomment/asset/css/ja.ie_rtl.php')) {
                    JHTML::stylesheet('components/com_jacomment/asset/css/' . 'ja.ie.php');
                }
                if (file_exists(JPATH_BASE . DS . 'templates/' . $mainframe->getTemplate() . '/css/ja.ie_rtl.php')) {
                    JHTML::stylesheet('templates/' . $mainframe->getTemplate() . '/css/' . 'ja.ie_rtl.php');
                }

                if (file_exists(JPATH_BASE . DS . 'components/com_jacomment/themes/' . $theme . '/css/style_rtl.css')) {
                    JHTML::stylesheet('components/com_jacomment/themes/' . $theme . '/css/' . 'style_rtl.css');
                }
                if (file_exists(JPATH_BASE . DS . 'templates' . DS . $mainframe->getTemplate() . DS . 'html' . DS . "com_jacomment" . DS . "themes" . DS . $theme . DS . "css" . DS . "style_rtl.css")) {
                    JHTML::stylesheet('templates/' . $mainframe->getTemplate() . '/html/com_jacomment/themes/' . $theme . '/css/' . 'style_rtl.css');
                }

                if (file_exists(JPATH_BASE . DS . 'components/com_jacomment/themes/' . $theme . '/css/style.ie_rtl.css')) {
                    JHTML::stylesheet('components/com_jacomment/themes/' . $theme . '/css/' . 'style_ie_rtl.css');
                }
                if (file_exists(JPATH_BASE . DS . 'templates' . DS . $mainframe->getTemplate() . DS . 'html' . DS . "com_jacomment" . DS . "themes" . DS . $theme . DS . "css" . DS . "style.ie_rtl.css")) {
                    JHTML::stylesheet('templates/' . $mainframe->getTemplate() . '/html/com_jacomment/themes/' . $theme . '/css/' . 'style.ie_rtl.css');
                }
            }

            if (file_exists(JPATH_BASE . DS . 'templates/' . $mainframe->getTemplate() . '/css/ja.comment.custom.css')) {
                JHTML::stylesheet('templates/' . $mainframe->getTemplate() . '/css/' . 'ja.comment.custom.css');
            }

            define('JACOMMENT_GLOBAL_CSS', true);
        }
    }
}
