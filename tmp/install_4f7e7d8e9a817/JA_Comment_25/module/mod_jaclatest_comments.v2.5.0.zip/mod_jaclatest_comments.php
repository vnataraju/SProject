<?php
/**
 * ------------------------------------------------------------------------
 * JA Latest Comment Module for Joomla 2.5
 * ------------------------------------------------------------------------
 * Copyright (C) 2004-2011 J.O.O.M Solutions Co., Ltd. All Rights Reserved.
 * @license - GNU/GPL, http://www.gnu.org/licenses/gpl.html
 * Author: J.O.O.M Solutions Co., Ltd
 * Websites: http://www.joomlart.com - http://www.joomlancers.com
 * ------------------------------------------------------------------------
 */

defined('_JEXEC') or die('Restricted access');

// Include the syndicate functions only once
require_once (dirname(__FILE__) . DS . 'helper.php');
modJACLatestItemsHelper::loadStyle($module);
$list = modJACLatestItemsHelper::getList($params);
modJACLatestItemsHelper::parseItems($params, $list);
require (JModuleHelper::getLayoutPath('mod_jaclatest_comments'));
?>